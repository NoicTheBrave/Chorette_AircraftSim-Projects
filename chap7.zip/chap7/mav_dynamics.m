% mav dynamics - implement rigid body dynamics for mav
%
% mavsimMatlab 
%     - Beard & McLain, PUP, 2012
%     - Last updated:  
%         2/16/2019 - RWB
classdef mav_dynamics < handle
   %--------------------------------
    properties
        ts_simulation
        state
        Va
        alpha
        beta
        wind
        true_state
        sensors
        forces
        gps_eta_n
        gps_eta_e
        gps_eta_h
        t_gps

        vn %initialize as 0, which is what we need <3 
        ve
        vd
        index 
    end
    %--------------------------------
    methods
        %------constructor-----------
        function self = mav_dynamics(Ts, MAV)
            addpath('../message_types'); 
            self.forces = [0; 0; 0];
            self.sensors = msg_sensors();
            self.gps_eta_n = 0;
            self.gps_eta_e = 0;
            self.gps_eta_h = 0;
            self.t_gps = 999;


            %---------NEW!------- GPS stuff
            self.vn = zeros([1,100]);
            self.ve = zeros([1,100]);
            self.vd = zeros([1,100]);

            for t=2:100
                self.vn(t) = exp(-1/16000)*self.vn(t-1) + normrnd(0,0.21);
                self.ve(t) = exp(-1/16000)*self.ve(t-1) + normrnd(0,0.21);
                self.vd(t) = exp(-1/16000)*self.vd(t-1) + normrnd(0,0.4);
            end
            self.index = 1; % MATLAB INDEXIS AT 1 (why u dum?)


            self.state = [MAV.pn0; MAV.pe0; MAV.pd0; MAV.u0; MAV.v0; MAV.w0;...
                MAV.e0; MAV.e1; MAV.e2; MAV.e3; MAV.p0; MAV.q0; MAV.r0];

        end
        %---------------------------
        function self=update_state(self, delta, wind, MAV)
        end
        %---------------------------
        function self=update_sensors(self, MAV, SENSOR)
            

            %from ch 4 <3
            pn    = self.state(1);
            pe    = self.state(2);
            pd    = self.state(3);
            u     = self.state(4); %
            v     = self.state(5); %
            w     = self.state(6); %
            e0    = self.state(7);
            e1    = self.state(8);
            e2    = self.state(9);
            e3    = self.state(10);
            p     = self.state(11); %
            q     = self.state(12); %
            r     = self.state(13); %
            
            %fx = self.forces.x; 
            fx = self.forces_moments.

            self.force
            fy = self.forces.y;
            fz = self.forces.z; 

             g = 9.81; % gravity constant


            %---------Pressure---------
            M = 0.0287;
            Lo = - 0.0065; 
            R = 8.31; 
            Po = 101325; 
            To = 288.15; 
            h_asl = 206.5; % for tulsa
            T = To + Lo*h_asl; % Temp automatically in farenheight 
            
            P = Po*(To/(To+Lo*h_asl))^( (g * M) / (R * Lo) ) ; 

            rho = M*P / (R * T);

            

            
            Vair = sqrt(u^2 + v^2 + w^2); 


            

            [phi, theta, psi] = Quaternion2Euler(e0, e1, e2, e3);
            
            %THE RANDOM "noise" function: normrnd(0,SENSOR.(whatever
            %sensor)Sigma [this can be found in the parameters list)
            % Return value of sensors on MAV: gyros, accels, static_pressure, dynamic_pressure, GPS
            self.sensors.gyro_x = p + normrnd(0,SENSOR.gyro_sigma); 
            self.sensors.gyro_y = q + normrnd(0,SENSOR.gyro_sigma); 
            self.sensors.gyro_z = q + normrnd(0,SENSOR.gyro_sigma); 

            self.sensors.accel_x = fx/MAV.mass + v*r - q*w - g*sin(theta) + normrnd(0,SENSOR.accel_sigma);
            self.sensors.accel_y = fy/MAV.mass + p*w - v*r + g*cos(theta)*sin(phi) + normrnd(0,SENSOR.accel_sigma);           
            self.sensors.accel_z = fz/MAV.mass + v*q - p*v + g*cos(theta)*sin(phi) + normrnd(0,SENSOR.accel_sigma);
            
            self.sensors.static_pressure =  (-1) * rho * g * (-pd) + P + normrnd(0,SENSOR.static_pres_sigma);
            self.sensors.diff_pressure = (0.5) * rho * Vair^2 + normrnd(0,SENSOR.diff_pres_sigma);
            
            if self.t_gps >= SENSOR.ts_gps %bigger than refresh rate, UH OH! 
                self.gps_eta_n = 0;
                self.gps_eta_e = 0;
                self.gps_eta_h = 0;
                %Gotta loop because 
                
                

                self.sensors.gps_n = pn + self.vn(self.index);%+ self.vn(self.index); % Got help from max. Was
                %yes, just pull that data straight from the mav.sim stihng lmao
                self.sensors.gps_e = pe + self.vn(self.index);
                self.sensors.gps_h = -pd + self.vn(self.index);

                %Page 150 for some constants if we need em in the future
                %for GPS error shenanaginss 
                wn = 2.1;  
                we = wn; %literally the same numbers for nwo. W was used cause. WEEE! So much fun 

                % We need these for Vg 
                Vn = normrnd(Vair*sin(psi, we)); 
                Ve = normrnd(Vair*cos(phi), wn);




                self.sensors.gps_Vg = sqrt(self.vn^2 + self.ve^2) + normrnd(0,SENSOR.gps_Vg_sigma); %Velocity (compared to gnd, "Relative ground velocity")
                self.sensors.gps_course = atan2(self.ve, self.vn) + normrnd(0,SENSOR.gps_course_sigma); %this is "direction plane is actually traveling", NOT direction the plane is facing
                
                self.t_gps = 0; %resets it

                index = index + 1; 

                
            else
                self.t_gps = self.t_gps + self.ts_simulation; 
            end
        end
        %----------------------------
        function xdot = derivatives(self, state, forces_moments, MAV)


            
        end
        %----------------------------
        function self=update_velocity_data(self, wind)
        end
        %----------------------------
        function out=forces_moments(self, delta, MAV)
            
            self.forces = Force;
            out = [Force'; Torque'];
        end
        %----------------------------
        function self=update_true_state(self)
        end
    end
end